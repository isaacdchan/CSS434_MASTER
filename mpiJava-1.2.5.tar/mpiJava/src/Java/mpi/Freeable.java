/*
 * File         : Freeable.java
 * Author       : Bryan Carpenter
 * Created      : Wed Jan 15 23:14:43 EST 2003
 * Revision     : $Revision: 1.1 $
 * Updated      : $Date: 2003/01/16 16:39:34 $
 */

package mpi;

abstract class Freeable {
    abstract void free() ;
}

