/* version number */

#undef  VERSION
